import React from 'react'
import Budget from './Budget'
import Department from './Department'
import Employee from './Employee'

const Home = () => {
  return (
    <div>
   <h1>Add the Employee </h1>
    </div>
  )
}

export default Home
