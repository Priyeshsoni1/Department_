import React, { useEffect, useState } from "react";
import axios from "axios";
import { NavLink } from "react-router-dom";
import "./department.css";
import {BsFillPlusSquareFill} from "react-icons/bs"
import { Table} from 'react-bootstrap';
const Department = () => {
  const [data, setData] = useState([]);
  const handleData = () => {
    axios.get("http://localhost:3005/data").then((res) => setData(res.data));
  };
  useEffect(() => {
    handleData();
  },[]);
 

        return (
          <div className="department">
            <div className="container">
              <div className="departmentName">
                <span className="departName">Department Name</span>
                <span className="dropdownDepartment">
                  <select name="cars" id="cars">
                    <option value="volvo">Hr</option>
                    <option value="saab">Manager</option>
                    <option value="opel">Developer</option>
                   
                  </select>
                </span>
              </div>
              <div className="description">
                <span className="descr">Description</span>
                <span className="descdetail">This Hr department of Emeis we take care of team</span>

              </div>
              <div className="date">
                <span className="startdate">Start Date</span>
                <input type="date" className="inputDate" />
                <span className="icon">date icon</span>
              </div>

              <div className="buttons">
                <button className="cancel">Cancel</button>
                <button className="save">Save</button>
              </div><hr />
              <div className="search">
                
                <button className="searchbut">
                  Search
                </button>
                <input type="text" className="inpsearch" />
              </div>
              <div className="tableemployee">
               
                  <NavLink to="/create">
                    <BsFillPlusSquareFill/>
                  </NavLink>
              

              <Table striped bordered hover>
      <thead>
        <tr>
          <th>Employee Name</th>
          <th>Age</th>
          <th>Nick Name</th>
          <th>Employee</th>
        </tr>
      </thead>  
      
        {
          data.map((u)=>
          {
            return(
              
        <tbody>
        <tr>
          <td> {u.name}</td>
          <td>{u.age}</td>
          <td>{u.nick}</td>
          <td><input type={"checkbox"} checked={u.employee?true:false} /></td>
        </tr>
        </tbody>
          
            )
          })
        }
      
      </Table>
      
  

              </div>
              

        
            </div>
          </div>
        );
      }


export default Department;
