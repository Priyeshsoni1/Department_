import React from 'react'

const Budget = () => {
  return (
    <div>
      budget
    </div>
  )
}

export default Budget
