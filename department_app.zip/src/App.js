import React from 'react'
import {  Route ,Routes} from 'react-router-dom';

import Department from "./component/Department"
import Employee from "./component/Employee"
import Budget from "./component/Budget"
import Home from './component/Home';
import NavigationBar from './NavigationBar';
import Create from "./component/Create";

const App = () => {
  return (
    <div>
          <NavigationBar/>
      
            <Routes>
                <Route  path='/' element={<Home/>}/>
                <Route path='/department' element={<Department/>}/>
                <Route path='/employee' element={<Employee/>}/>
                <Route path='/budget' element={<Budget/>}/>
                <Route path='/create' element={<Create/>}/>
             </Routes>
         
    </div>
  )
}

export default App
